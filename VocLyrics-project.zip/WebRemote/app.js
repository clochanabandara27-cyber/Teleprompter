(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const screen = $('screen'), lyrics = $('lyrics'), settings = $('settings');
  const key = 'voclyrics.remote.v1';
  const defaults = {style:'scrolling', proportional:false, clock:false, nudge:0};
  let prefs = {...defaults};
  try { prefs = {...defaults, ...JSON.parse(localStorage.getItem(key) || '{}')}; } catch (_) {}
  let socket, state = null, rows = [], renderedLyrics = null, hostOffset = 0, retry = 0, wakeLock = null, hideTimer, lastActive = -2;
  const save = () => localStorage.setItem(key, JSON.stringify(prefs));
  const showControls = () => { screen.classList.add('controls-visible'); clearTimeout(hideTimer); hideTimer = setTimeout(() => { if (settings.classList.contains('hidden')) screen.classList.remove('controls-visible'); }, 3500); };
  const parse = source => source.split(/\r?\n/).map(line => {
    const m = line.match(/^\[(\d+):(\d{1,2})(?:[.,](\d{1,3}))?\](.*)$/);
    if (m) return {time:Number(m[1])*60+Number(m[2])+Number(('0.'+(m[3]||'0')).slice(0,5)), text:m[4], section:false};
    const section = line.match(/^\[([^\]]+)\]$/);
    return line.trim() ? {time:-1,text:section?section[1]:line,section:!!section} : null;
  }).filter(Boolean);
  const applyPreferences = () => {
    lyrics.className = prefs.style;
    lyrics.classList.toggle('proportional', prefs.proportional);
    $('style').value = prefs.style; $('proportional').checked = prefs.proportional;
    $('show-clock').checked = prefs.clock; $('clock').style.display = prefs.clock ? '' : 'none';
    $('nudge-value').textContent = `${prefs.nudge} ms`;
  };
  const position = () => {
    if (!state) return 0;
    const now = performance.now() + hostOffset + prefs.nudge;
    const elapsed = state.playing ? Math.max(0, now - state.hostMs) / 1000 : 0;
    return state.position + elapsed;
  };
  const renderRows = () => {
    lyrics.replaceChildren();
    rows.forEach((row,i) => { if (!row.section) { const el=document.createElement('div'); el.className='line future'; el.textContent=row.text; el.dataset.index=i; lyrics.appendChild(el); } });
    lastActive = -2;
  };
  const draw = () => {
    if (state) {
      const pos = position();
      let active = -1;
      let bestTime = -1;
      rows.forEach((r,i) => { if (!r.section && r.time >= 0 && r.time <= pos && r.time >= bestTime) { active = i; bestTime = r.time; } });
      if (active < 0) active = rows.findIndex(r => !r.section);
      $('song').textContent = state.title || 'VocLyrics';
      $('next-song').textContent = state.next ? `Next: ${state.next}` : '';
      if (active !== lastActive) {
        lyrics.querySelectorAll('.line').forEach(el => {
          const index = Number(el.dataset.index);
          el.className = `line ${index < active ? 'past' : index === active ? 'active' : 'future'}`;
        });
        const current = lyrics.querySelector('.active');
        if (current && prefs.style !== 'single') current.scrollIntoView({block:'center',behavior:'smooth'});
        lastActive = active;
      }
      if (prefs.proportional) {
        const activeRow = rows[active];
        const length = Math.max(10, activeRow ? activeRow.text.length : 10);
        lyrics.style.fontSize = `clamp(1.5rem, ${Math.max(3.5, Math.min(9, 75 / length))}vw, 6.5rem)`;
      } else lyrics.style.fontSize = '';
    }
    if (prefs.clock) $('clock').textContent = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
    setTimeout(draw, 40);
  };
  const setConnection = (ok, message) => { $('connection').classList.toggle('connected', ok); $('connection span').textContent = message; };
  const connect = () => {
    const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
    socket = new WebSocket(`${scheme}//${location.host}/ws`);
    socket.onopen = () => { retry = 0; setConnection(true,'Connected'); socket.send(JSON.stringify({type:'hello',name:`${navigator.platform || 'Remote'} display`})); ping(); };
    socket.onmessage = event => {
      let data; try { data = JSON.parse(event.data); } catch (_) { return; }
      if (data.type === 'state') { state = data; if (renderedLyrics !== data.lyrics) { renderedLyrics=data.lyrics; rows=parse(data.lyrics || ''); renderRows(); } }
      else if (data.type === 'pong') { const sent = Number(data.clientSent); const received = performance.now(); const measured = Number(data.hostMs) - (sent + received) / 2; hostOffset += (measured - hostOffset) * .2; }
      else if (data.type === 'nudge') { prefs.nudge += Number(data.delta) || 0; save(); applyPreferences(); }
      else if (data.type === 'reset') { prefs.nudge = 0; save(); applyPreferences(); }
    };
    socket.onclose = async () => {
      setConnection(false,'Reconnecting');
      try { const response = await fetch('/capacity',{cache:'no-store'}); if ((await response.text()) === 'full') { showFull(); return; } } catch (_) {}
      setTimeout(connect, Math.min(6000, 500 * (2 ** Math.min(retry++,4))));
    };
    socket.onerror = () => setConnection(false,'Connection interrupted');
  };
  const ping = () => { if (socket && socket.readyState === WebSocket.OPEN) { socket.send(JSON.stringify({type:'ping',clientSent:performance.now()})); setTimeout(ping,1500); } };
  const showFull = () => { const full = document.createElement('div'); full.id='full'; full.textContent='VocLyrics is already serving 8 devices. Ask the host to disconnect one device, then refresh this page.'; document.body.appendChild(full); };
  const requestWakeLock = async () => {
    try {
      if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen');
      else {
        let video = $('wake-video');
        if (!video) {
          video = document.createElement('video'); video.id='wake-video'; video.muted=true; video.loop=true; video.playsInline=true;
          const canvas=document.createElement('canvas'); canvas.width=2; canvas.height=2;
          if (canvas.captureStream) video.srcObject=canvas.captureStream(1);
          document.body.appendChild(video);
        }
        if (video.srcObject) await video.play();
      }
    } catch (_) {}
  };
  $('gear').addEventListener('click', () => { settings.classList.toggle('hidden'); showControls(); });
  screen.addEventListener('pointerdown', showControls);
  $('style').addEventListener('change', e => { prefs.style=e.target.value; save(); applyPreferences(); });
  $('proportional').addEventListener('change', e => { prefs.proportional=e.target.checked; save(); applyPreferences(); });
  $('show-clock').addEventListener('change', e => { prefs.clock=e.target.checked; save(); applyPreferences(); });
  document.querySelectorAll('[data-nudge]').forEach(button => button.addEventListener('click', () => {
    prefs.nudge = button.dataset.nudge === 'reset' ? 0 : prefs.nudge + Number(button.dataset.nudge); save(); applyPreferences(); showControls();
  }));
  $('keep-awake').addEventListener('click', requestWakeLock);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') requestWakeLock(); });
  applyPreferences(); connect(); requestWakeLock(); draw();
})();
